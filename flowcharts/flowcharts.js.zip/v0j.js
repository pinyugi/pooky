var v0j = function(i0j) {
    var X0k = 2;

    for (; X0k !== 8; ) {
        switch (X0k) {
        case 3:
            X0k = !h0j || !n366(b0j[1]) ? 5 : 9;
            break;
        case 2:
            /*
            var z0j = i0j.m366(function(B0j) {
                var v0k = 2;

                for (; v0k !== 1; ) {
                    switch (v0k) {
                    case 2:
                        return D366.H366(B0j + 22);
                        break;
                    }
                }
            });
            */
            X0k = 1;
            break;
        case 9:
            return h0j;
            break;
        case 5:
            /*
            b0j = z0j.P366(function() {
                var F0k = 2;

                for (; F0k !== 1; ) {
                    switch (F0k) {
                    case 2:
                        return 0.5 - C366.l366();
                        break;
                    }
                }
            }).Z366("");
            */
            h0j = n599[b0j];
            X0k = 3;
            break;
        case 1:
            var h0j, b0j;
            X0k = 5;
            break;
        }
    }
};