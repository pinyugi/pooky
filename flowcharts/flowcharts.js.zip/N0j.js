var N0j = function(V0j) {
    var p0k = 2;

    for (; p0k !== 6; ) {
        switch (p0k) {
        case 1:
            L0j.f366.L366(L0j, L0j.j366(-4).j366(0, 3));
            p0k = 5;
            break;
        case 5:
            return g0j++, L0j[V0j];
            break;
        case 2:
            p0k = g0j === 0 && V0j === 1130 ? 1 : 4;
            break;
        case 4:
            p0k = g0j === 1 && V0j === 6667 ? 3 : 9;
            break;
        case 3:
            L0j.f366.L366(L0j, L0j.j366(-3).j366(0, 2));
            p0k = 5;
            break;
        case 8:
            L0j.f366.L366(L0j, L0j.j366(-2).j366(0, 1));
            p0k = 5;
            break;
        case 7:
            N0j = x0j;
            p0k = 5;
            break;
        case 9:
            p0k = g0j === 2 && V0j === 10850 ? 8 : 7;
            break;
        }
    }
};